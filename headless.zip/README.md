# Headless by Wolf+Partners - A blank theme with page redirect for your Wordpress Headless

## Auto-zip Configuration

After cloning the repository, run:

- **Windows**:  
  ```powershell
  .\setup.ps1
  ```

- **Linux/macOS**:  
  ```bash
  chmod +x setup.sh && ./setup.sh
  ```

The zip file `headless.zip` will be automatically updated on every file change.
