# Configura permissões e inicia monitoramento
Set-ExecutionPolicy RemoteSigned -Scope Process -Force
Start-Process powershell -ArgumentList "-File .\watch_and_zip.ps1" -WindowStyle Hidden 