#!/bin/bash
chmod +x watch_and_zip.sh
./watch_and_zip.sh 